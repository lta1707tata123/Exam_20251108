S = float(input("Quang duong di duoc: "))
if S < 1:
    print(f"{S * 7000}")
elif S < 5:
    print(f"{(S - 1) * 6500 + 7000}")
else:
    print(f"{(S - 5) * 6000 + 7000 + 4 * 6500}")