mat_khau_moi_1 = input("Hay nhap mat khau moi: ")
mat_khau_moi_2 = input("Hay xac nhan lai mat khau moi lan 2: ")
if mat_khau_moi_1 == mat_khau_moi_2:
    print("Mat khau da duoc doi thanh cong")
else:
    print("Mat khau khong giong nhau roi")
    