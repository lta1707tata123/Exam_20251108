N = int(input("Nhap nam duong lich N: "))
dieu_kien_1 = (N % 4 == 0) and (N % 100 != 0)
dieu_kien_2 = (N % 400 == 0)
nam_nhuan = dieu_kien_1 or dieu_kien_2
if nam_nhuan:
    print(f"Nam {N} la Nam nhuan.")
else:
    print(f"Nam {N} KHONG phai la nam nhuan.")