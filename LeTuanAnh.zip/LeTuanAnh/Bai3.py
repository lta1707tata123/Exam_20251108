N = int(input("Nhap gia tri nhiet do N (do C): "))
if N > 30:
    thong_bao = "Troi dang nong"
elif N < 20:
    thong_bao = "Troi dang lanh"
else:
    thong_bao = "Thoi tiet de chiu"
print(f"Voi nhiet do {N}doC, thong bao thoi tiet la: {thong_bao}")
